/* Cinematic scroll reveals + small interactions */
(function(){
  // Mark JS as ready BEFORE anything else, so the hide-by-default CSS only kicks in
  // once we have a chance to flip elements visible.
  document.documentElement.classList.add('js-on');

  const observe = () => {
    if (!('IntersectionObserver' in window)) {
      // Safari < 12 / very old — show everything immediately
      document.querySelectorAll('.reveal, .reveal-stagger, .reveal-letters').forEach(el => el.classList.add('in'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.05, rootMargin: '0px 0px -4% 0px' });

    document.querySelectorAll('.reveal, .reveal-stagger, .reveal-letters').forEach(el => {
      // Items already in viewport at load — flip on next frame
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        requestAnimationFrame(() => el.classList.add('in'));
      } else {
        io.observe(el);
      }
    });

    // Safety net: anything still hidden after 1.6s is forced visible.
    setTimeout(() => {
      document.querySelectorAll('.reveal, .reveal-stagger, .reveal-letters').forEach(el => {
        if (!el.classList.contains('in')) el.classList.add('in');
      });
    }, 1600);
  };

  // Wrap each line in hero h1 for letter reveal
  function prepHero(){
    document.querySelectorAll('.reveal-letters h1 .l1, .reveal-letters h1 .l2').forEach(line => {
      const text = line.textContent;
      line.innerHTML = '<span>' + text + '</span>';
    });
  }

  function dupMarquee(){
    document.querySelectorAll('.marquee-track').forEach(track => {
      track.innerHTML = track.innerHTML + track.innerHTML;
    });
  }

  function navScroll(){
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', (e) => {
        const id = a.getAttribute('href');
        if (id.length > 1) {
          const t = document.querySelector(id);
          if (t) {
            e.preventDefault();
            window.scrollTo({ top: t.getBoundingClientRect().top + window.scrollY - 80, behavior: 'smooth' });
          }
        }
      });
    });
  }

  function heroParallax(){
    const plate = document.querySelector('.hero-plate .plate');
    if (!plate) return;
    let raf = null;
    const apply = () => {
      const r = plate.getBoundingClientRect();
      const vh = window.innerHeight;
      const offset = Math.max(-1, Math.min(1, (r.top + r.height/2 - vh/2) / vh));
      plate.style.transform = 'translateY(' + (offset * -16) + 'px)';
      raf = null;
    };
    window.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(apply); }, { passive: true });
    apply();
  }

  const init = () => { prepHero(); dupMarquee(); observe(); navScroll(); heroParallax(); };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
